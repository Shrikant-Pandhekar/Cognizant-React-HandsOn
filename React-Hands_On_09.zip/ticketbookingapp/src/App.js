import "./App.css";
import { useState } from "react";

function App() {
  const [page, setPage] = useState("Please sign up");
  const [button, setButton] = useState("Login");
  function handleEvent() {
    setPage("Welcome Back");
    setButton("Logout");
  }
  function handleEventNew() {
    setPage("Please sign up");
    setButton("Login");
  }

  return (
    <div className="container">
      <h1>{page}</h1>
      <br />
      <br />
      <button onClick={button === "Login" ? handleEvent : handleEventNew}>
        {button}
      </button>
    </div>
  );

  // return (
  //   <div className="container">
  //     <h1>{page}</h1>
  //     <br />
  //     <br />
  //     <button onClick={button === "Login" ? handleUser : handleGuest}>
  //       {button}
  //     </button>
  //   </div>
  // );
}

export default App;
