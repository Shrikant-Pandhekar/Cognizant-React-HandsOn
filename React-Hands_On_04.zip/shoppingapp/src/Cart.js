import React, { Component } from "react";

export class Cart extends Component {
  render() {
    return (
      <>
        <tr className="header">
          <td>Name</td>
          <td>Price</td>
        </tr>
        {this.props.item.map((item) => (
          <tr>
            <td>{item.itemname}</td>
            <td>{item.price}</td>
          </tr>
        ))}
      </>
    );
  }
}

export default Cart;
