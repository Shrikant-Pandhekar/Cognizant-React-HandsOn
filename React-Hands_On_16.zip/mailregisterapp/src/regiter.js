import React, { useState } from "react";

const Regiter = () => {
  const [details, setDetails] = useState({
    name: "",
    email: "",
    pass: "",
  });
  function handleInput(e) {
    const { name, value } = e.target;
    setDetails({
      ...details,
      [name]: value,
    });
  }
  //   console.log(details);
  function validateForm(params) {
    var format = /^[a-zA-Z0-9]+@+[a-zA-Z0-9]+.+[A-z]/;
    var msg = "";
    switch (params) {
      case details.name:
        msg = details.name.length < 5 ? "Name must be  5 character long" : null;
        return msg;

      case details.email:
        msg = !details.email.match(format) ? "Email is not valid" : null;
        return msg;

      case details.pass:
        msg =
          details.pass.length < 8 ? "Password must be 8 character long" : null;
        return msg;

      default:
        msg = "Valid Form";
        return msg;
    }
  }
  function handleForm(e) {
    const { name, email, pass } = details;
    console.log(name + email + pass);
    e.preventDefault();
    if (validateForm(name) != null) {
      alert(validateForm(name));
    }
    if (validateForm(email)) {
      alert(validateForm(email));
    }
    if (validateForm(pass) != null) {
      alert(validateForm(pass));
    }
  }
  return (
    <div className="container">
      <h1 className="heading">Register Here!!!</h1>
      <form action="" onSubmit={handleForm}>
        <table>
          <tr>
            <td>Name:</td>
            <td>
              <input
                type="text"
                id="uname"
                name="name"
                onChange={handleInput}
              ></input>
            </td>
          </tr>
          <tr>
            <td>Email:</td>
            <td>
              <input
                type="email"
                id="uemail"
                name="email"
                onChange={handleInput}
              ></input>
            </td>
          </tr>
          <tr>
            <td>Password:</td>
            <td>
              <input
                type="password"
                id="upass"
                name="pass"
                onChange={handleInput}
              ></input>
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <button>Submit</button>
            </td>
          </tr>
        </table>
      </form>
    </div>
  );
};

export default Regiter;
