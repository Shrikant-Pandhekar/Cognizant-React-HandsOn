import "./App.css";
import Regiter from "./regiter";

function App() {
  return <Regiter />;
}

export default App;
