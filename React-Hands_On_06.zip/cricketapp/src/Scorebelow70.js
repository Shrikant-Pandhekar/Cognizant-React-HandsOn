import React from "react";

const Scorebelow70 = (players) => {
  return players.players.map((item) => {
    if (item.Score <= 70) {
      return (
        <div>
          <li>
            Mr. {item.playername}
            <span> {item.Score} </span>
          </li>
        </div>
      );
    }
  });
};

export default Scorebelow70;
