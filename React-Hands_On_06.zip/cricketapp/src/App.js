import "./App.css";
import ListOfPlayer from "./ListOfPlayer";
import Scorebelow70 from "./Scorebelow70";
import ListofindianPlayers from "./ListofindianPlayers";

function OddPlayers([first, , third, , fifth]) {
  return (
    <div>
      <li>First: {first}</li>
      <li>Third: {third}</li>
      <li>Fifth: {fifth}</li>
    </div>
  );
}
function EvenPlayers([, second, , fourth, , sixth]) {
  return (
    <div>
      <li>Second: {second}</li>
      <li>Fourth: {fourth}</li>
      <li>Sixth: {sixth}</li>
    </div>
  );
}

function App() {
  const players = [
    { playername: " Jack", Score: 50 },
    { playername: " Michael", Score: 70 },
    { playername: " John", Score: 40 },
    { playername: " Ann", Score: 61 },
    { playername: " Elizabeth", Score: 61 },
    { playername: " Sachin", Score: 95 },
    { playername: " Dhoni", Score: 100 },
    { playername: " Virat", Score: 84 },
    { playername: " jadeja", Score: 64 },
    { playername: " Raina", Score: 75 },
    { playername: " Rohit", Score: 80 },
  ];

  const IndianTeam = [
    "Sachin1",
    "Dhoni2",
    "Virat3",
    "Rohit4",
    "Yuvraj5",
    "Raina6",
  ];
  const T20Players = ["First Player", "Second Player", "Third Player"];
  const RanjiTrophyPlayers = ["Fourth Player", "Fifth Player", "Sixth Player"];
  const IndianPlayers = [...T20Players, ...RanjiTrophyPlayers];

  var flag = true;
  if (flag === true) {
    return (
      <div>
        <h1> List of Players</h1>
        <ListOfPlayer players={players} />
        <hr />
        <h1> List of Players having Scores Less than 70 </h1>
        <Scorebelow70 players={players} />
      </div>
    );
  } else {
    return (
      <div>
        <div>
          <h1> Indian Team </h1>
          <h1> Odd Players </h1>
          {OddPlayers(IndianTeam)}
          <hr />
          <h1> Even Players</h1>
          {EvenPlayers(IndianTeam)}
        </div>
        <hr />
        <div>
          <h1> List of Indian Players Merged:</h1>
          <ListofindianPlayers IndianPlayers={IndianPlayers} />
        </div>
      </div>
    );
  }
}

export default App;
