import React from "react";

const ListOfPlayer = (players) => {
  console.log(players.players.map((item) => item));
  return players.players.map((item) => {
    return (
      <div>
        <li>
          Mr. {item.playername}
          <span> {item.Score} </span>
        </li>
      </div>
    );
  });
};

export default ListOfPlayer;
