import React from "react";

const ListofindianPlayers = (IndianPlayers) => {
  return IndianPlayers.IndianPlayers.map((item) => {
    return (
      <div>
        <li>Mr. {item}</li>
      </div>
    );
  });
};

export default ListofindianPlayers;
