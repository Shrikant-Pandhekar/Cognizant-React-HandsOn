import "./App.css";

function App() {
  return <h1>Welcome the first session of</h1>;
}

export default App;
