import React, { useState } from "react";

const ComplaintRegister = () => {
  const [name, setName] = useState("");
  const [cnumber, setCnumber] = useState(1);
  function handleInput(e) {
    console.log(e.target.value);
    setName(e.target.value);
  }
  function handleForm(event) {
    setCnumber(cnumber + 1);
    var msg =
      "Thanks " +
      name +
      "\nYour Complaint was Submitted \r\nTransaction ID is " +
      cnumber;
    alert(msg);
    event.preventDefault();
  }
  return (
    <div className="container">
      <h1>Register you complaints here !!!</h1>
      <table>
        <tr>
          <td>Name:</td>
          <td>
            <input type="text" id="name" onChange={handleInput}></input>
          </td>
        </tr>
        <tr>
          <td>Complaint:</td>
          <td>
            <textarea name="complaint" id="" cols="21" rows="3"></textarea>
          </td>
        </tr>
        <tr>
          <td></td>
          <td>
            <button onClick={handleForm}>Submit</button>
          </td>
        </tr>
      </table>
    </div>
  );
};

export default ComplaintRegister;
