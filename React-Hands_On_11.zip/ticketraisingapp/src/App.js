import logo from "./logo.svg";
import "./App.css";
import ComplaintRegister from "./component/ComplaintRegister";

function App() {
  return <ComplaintRegister />;
}

export default App;
