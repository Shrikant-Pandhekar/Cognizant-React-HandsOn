import React, { useEffect, useState } from "react";

const Getuser = () => {
  const [user, setUser] = useState({
    person: null,
    loading: true,
  });

  useEffect(() => {
    componentDidMount();
  }, []);

  async function componentDidMount() {
    const url = "https://api.randomuser.me/";
    const response = await fetch(url);
    const data = await response.json();
    setUser({ person: data.results[0], loading: false });
    console.log(data.results[0]);
  }

  return (
    <div className="center">
      {user.loading || !user.person ? (
        <div> loading...</div>
      ) : (
        <div>
          <h1>
            {user.person.name.title}
            <span> {user.person.name.first} </span>
            <span> {user.person.name.last} </span>
          </h1>
          <img src={user.person.picture.large} alt="userPhoto" />
        </div>
      )}
    </div>
  );
};

export default Getuser;
