import "./App.css";
import Getuser from "./compoents/Getuser";

function App() {
  return <Getuser />;
}

export default App;
