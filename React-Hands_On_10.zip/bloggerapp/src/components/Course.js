import React from "react";

const Course = (props) => {
  const courseDetails = (
    <ul>
      {props.course.map((course) => (
        <div key={course.id}>
          <h1>{course.name}</h1>
          <h4>{course.date}</h4>
        </div>
      ))}
    </ul>
  );
  return (
    <div className="deatils">
      <h1>Course Deatils</h1>
      {courseDetails}
    </div>
  );
};

export default Course;
