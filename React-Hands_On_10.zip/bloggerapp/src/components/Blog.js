import React from "react";

const Blog = (props) => {
  const blogDeatils = (
    <ul>
      {props.blog.map((blog) => (
        <div key={blog.id}>
          <h1>{blog.blogName}</h1>
          <h3>{blog.pname}</h3>
          <h4>{blog.para}</h4>
        </div>
      ))}
    </ul>
  );
  return (
    <div className="deatils">
      <h1>Blog Deatils</h1>
      {blogDeatils}
    </div>
  );
};

export default Blog;
