import React from "react";

const Book = (props) => {
  const bookDeatils = (
    <ul>
      {props.book.map((book) => (
        <div key={book.id}>
          <h3>{book.bname}</h3>
          <h4>{book.price}</h4>
        </div>
      ))}
    </ul>
  );
  return (
    <div className="deatils">
      <h1>Book Deatils</h1>
      {bookDeatils}
    </div>
  );
};

export default Book;
