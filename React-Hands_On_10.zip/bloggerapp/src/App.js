import "./App.css";
import Book from "./components/Book";
import Course from "./components/Course";
import Blog from "./components/Blog";
import { books, BlogDetails, CourseDetail } from "./Details";

function App() {
  return (
    <div>
      <div className="container">
        <Course course={CourseDetail} />
        <Book book={books} />
        <Blog blog={BlogDetails} />
      </div>
    </div>
  );
}

export default App;
