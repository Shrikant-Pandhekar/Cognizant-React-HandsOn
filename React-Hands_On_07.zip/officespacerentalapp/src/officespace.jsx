import React from "react";
import "./App.css";
import img from "./office.jpg";

const Officespace = (houseList) => {
  const title = React.createElement(
    "h1",
    {},
    "Office Space, at Affordable Range"
  );

  const list = houseList.houseList.map((item) => {
    return (
      <div className="asd">
        <h2>Name: {item.name}</h2>
        <h3 className={item.rent < 60000 ? "red" : "green"}>
          Rent: {item.rent}
        </h3>
        <h3>Address: {item.address}</h3>
      </div>
    );
  });

  return (
    <div className="officedetails">
      {title}
      <img src={img} alt="office" width={400} height={200} />
      {list}
    </div>
  );
};

export default Officespace;
