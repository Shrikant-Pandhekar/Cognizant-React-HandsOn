import React from "react";
import "./App.css";
import Officespace from "./officespace";

function App() {
  const houseList = [
    {
      name: "DBS",
      rent: 50000,
      address: "Chennai",
    },
    {
      name: "QBS",
      rent: 60000,
      address: "Banglore",
    },
    {
      name: "BETA",
      rent: 100000,
      address: "Bhopal",
    },
    {
      name: "ALPHA",
      rent: 90000,
      address: "Delhi",
    },
    {
      name: "GAMMA",
      rent: 80000,
      address: "Jalandhar",
    },
  ];
  return (
    <div className="App">
      <Officespace houseList={houseList} />
    </div>
  );
}

export default App;
