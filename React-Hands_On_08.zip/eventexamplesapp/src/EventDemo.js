import React, { useState } from "react";

const EventDemo = () => {
  const [no, updateNumber] = useState(0);

  function increase() {
    updateNumber(no + 1);
    hello();
  }

  function decrease() {
    updateNumber(no - 1);
  }
  function hello() {
    alert("Hello! Member1");
  }

  function displayMsg(msg) {
    alert(msg);
  }

  function click() {
    alert("I was Clicked");
  }
  return (
    <div>
      {no}
      <br></br>
      <br></br>
      <button onClick={increase}>Increment</button>
      <br></br>
      <button onClick={decrease}>Decrement</button>
      <br></br>
      <button onClick={() => displayMsg("Welcome")}>Say Hello</button>
      <br></br>
      <button onClick={click}>Click on me</button>
    </div>
  );
};

export default EventDemo;
