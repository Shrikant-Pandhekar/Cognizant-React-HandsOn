import "./App.css";
import EventDemo from "./EventDemo";
import CurrencyConverter from "./CurrencyConverter";

function App() {
  return (
    <div>
      <EventDemo />
      <CurrencyConverter />
    </div>
  );
}

export default App;
