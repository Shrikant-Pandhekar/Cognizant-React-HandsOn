import React, { useState } from "react";

const CurrencyConverter = () => {
  const [values, setValues] = useState({
    amount: "",
    currency: "",
  });
  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
    });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(values);
    if (values.currency.toLowerCase() === "euro") {
      var total = values.amount * 80;
      alert("Converting the " + values.currency + " amount is " + total);
      setValues({ amount: "", currency: "" });
    } else {
      alert("Enter Valid Currency");
    }
  };
  return (
    <div>
      <h1 style={{ color: "green" }}>Currency Converter!!!!</h1>
      <form action="">
        <table>
          <tr>
            <td>Amount</td>
            <td>
              <input
                type="number"
                name="amount"
                id="amount"
                value={values.amount}
                onChange={handleChange}
              />
            </td>
          </tr>

          <tr>
            <td>Currency</td>
            <td>
              <input
                type="text"
                name="currency"
                id="currency"
                value={values.currency}
                onChange={handleChange}
              />
            </td>
          </tr>
          <tr>
            <td></td>
            <td>
              <button onClick={handleSubmit}>Submit</button>
            </td>
          </tr>
        </table>
      </form>
    </div>
  );
};

export default CurrencyConverter;
